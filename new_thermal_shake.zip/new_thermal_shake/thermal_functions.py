# Definición de funciones correspondiente a la generación aleatoria de posicion de atomos
# debido a la agitacion termica, siguiendo el concepto de average thermal length

# Módulos varios

import os
import numpy as np
import random

# Importar diccionario de masas molares

from utilities import * #(diccionario masas)

# Importar shake functions

def new_name(main,i,n):
    """ Crea un nombre en formato string para un archivo nuevo correspondiente 
    a las N pruebas del análisis de Montecarlo"""
    i=str(i)
    num=i
    if len(i)<len(str(n)):
        dif=len(str(n))-len(i)
        num='0'*dif+i
    return main.split('.')[0]+num+'.'+main.split('.')[1]

def randomX(x,R): # R indica el radio atómico en Angstroms 
    """Teniendo un vector x, se agita una esfera que lo contiene entregando una 
    nueva posición"""
    r=random.uniform(0,R)
    theta=random.uniform(0,2*np.pi)
    phi=random.uniform(0,np.pi)
    new_x=[0,0,0]
    new_x[0]=x[0]+r*np.cos(theta)*np.sin(phi)
    new_x[1]=x[1]+r*np.sin(theta)*np.sin(phi)
    new_x[2]=x[2]+r*np.cos(phi)
    return new_x

def dec3(x):
    """Redondeo de un número float a 3 decimales para correcta escritura en .pqr"""
    valor= str(round(x,3))
    if '.' in valor:
        decimal=valor.split('.')[-1]
        if len(decimal)<3:
            decimal=decimal+'000'
            decimal=decimal[:3]
            return valor.split('.')[0]+'.'+decimal
        else:
            return valor
    else:
        return valor+'.000'

def nombre_atomo(atomo,es_biomolecula):
    """ Tomando un string correspondiente al átomo de un archivo pdb (formato C1, C2, etc) 
    se retorna sólo el elemento químico sin el número.
    En caso de que sea biomolecula, puede que algunos atomos se nombren en formato CA (carbono alpha)
    y derivados, en ese caso se retorna solo CHONSP"""
    final=''
    for caracter in atomo:
        if caracter not in "0123456789":
            final+=caracter
    if es_biomolecula:
        for elem in 'CHONSP':
            if elem in final:
                return elem
    return final

# Script para la definir diccionarios de average_thermal_length, como llaves se tendrán los nombres de los elementos
# y como valores los radios de las esferas donde se agitan los átomos

ATL_dic = {}
kB = 1.3806e-23 # Constante de Stefan-Boltzmann
t  = 1e-9 # Tiempo característico, del orden de los 10 ns
T  = 298 # Temperatura en Kelvin
vt = lambda m,T: np.sqrt(kB*t/m) # thermal velocity en funcion de masa y temperatura (298K por defecto)
L  = lambda m,T: vt(m,T)*t*1e10  #1e10 convierte la unidad a Angstroms

for atomo,masa in masas.items():
    ATL_dic[atomo] = L(masa,T)

#Opciones generales
mainfile = '1pgb.pqr'
n_tests = 100

#Lo que no es info relevante se guarda en remark, lo que va después de atoms comoter, hetatm,master igual se queda

remarks=""""""
atoms=""""""
end=""""""
arch=open(mainfile)
post_atoms=False
for line in arch:
    data=line.split()
    if data[0]!='ATOM' and not post_atoms:
        remarks+=line
    elif data[0]=='ATOM':
        post_atoms=True
        atoms+=line
    else:
        end+=line
arch.close()

#Ahora es conveniente definie la función para crear un archivo aleatorio en base a la agitación térmica

def shake_file(mainfile,i,path,remarks=remarks): 
    file = open(path+new_name(mainfile,i,n_tests),'w')
    file.write(remarks)
    list_atoms=atoms.split('\n')
    for i in range(len(list_atoms)):
        linea=list_atoms[i].split()
        if len(linea)==0: continue
        atomo=nombre_atomo(linea[2],True) # 2 para pqr, -1 para pdb
        _x=list(map(float,linea[5:8])) # 5:8 pqr, 6:9 pdb
        _x=randomX(_x,ATL_dic[atomo])
        x,y,z=list(map(str,_x))
        lineareal=list(list_atoms[i])
        extension= mainfile.split('.')[-1]
        # Si es pdb 
        if extension == 'pdb':
            c=0
            for j in z[::-1]+' ':
                lineareal[53-c]=j
                c+=1
            c=0
            for j in y[::-1]+' ':
                lineareal[45-c]=j
                c+=1
            c=0
            for j in x[::-1]+' ':
                lineareal[37-c]=j
                c+=1
            file.write(''.join(lineareal)+'\n')
        # Si es pqr
        elif extension=='pqr':
            linea[5:8]=list(map(str,_x))
            file.write('\t'.join(linea)+'\n')
    file.write(end)
    file.close()
    return None

import bem_electrostatics
from time import time
import gc
from scipy.sparse import csr_matrix, SparseEfficiencyWarning
import warnings
warnings.simplefilter("ignore",SparseEfficiencyWarning)

# Directorio de archivos de prueba
path='tests/'
if path[:-1] not in os.listdir():
    os.mkdir(path[:-1])

csv_data=open('resultados.csv','w')
csv_data.write('ITERATION,SOLV. ENERGY,GMRES Iterations,Elapsed time,Number of elements\n')
csv_data.close()

imprimir=True

for i in range(n_tests):
    shake_file(mainfile,i,path)

for i in range(n_tests):
    test_file=path+new_name(mainfile,i,n_tests)
    try:
        if imprimir:
            start_time=time()
        protein=bem_electrostatics.solute(test_file,mesh_generator='nanoshaper',mesh_density=1)
        protein.gmres_tolerance=1e-4
        protein.gmres_max_iterations=400
        protein.calculate_solvation_energy()
        if imprimir: 
            ET=time()-start_time
            print('INFO: {0}i:{1}, {2}, {3}, {4} [s],{5}'.format('',i, 
            protein.solvation_energy,
            protein.solver_iteration_count, 
            round(ET,3),
            protein.mesh.number_of_elements))
        csv_data=open('resultados.csv','a')
        csv_data.write('{0},{1},{2},{3},{4}\n'.format(
            i,
            protein.solvation_energy,
            protein.solver_iteration_count,
            round(ET,3),
            protein.mesh.number_of_elements))
        csv_data.close()
    except KeyboardInterrupt:
        print('Interrupcion')
        break
    except OSError:
        #Algunas veces ocurren errores y mesh_temp queda ocupado, con esto se evita arrastrar el error a las moleculas siguientes
        if 'mesh_temp' in os.listdir():
            os.chdir('mesh_temp')
            for arch in os.listdir():
                os.remove(arch)
            os.chdir('..')
            os.rmdir('mesh_temp')
    except Exception:
        import sys
        exc_type,value,traceback=sys.exc_info()
        print(exc_type.__name__)
        print(traceback)



