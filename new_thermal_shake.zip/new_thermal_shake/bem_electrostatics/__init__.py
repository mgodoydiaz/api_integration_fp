import bempp.api
import os
from bem_electrostatics.solute import solute

BEM_ELECTROSTATICS_PATH = os.path.abspath(os.path.dirname(os.path.realpath(__file__)))
#WORKING_PATH = os.getcwd()